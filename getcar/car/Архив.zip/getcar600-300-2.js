(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.back = function() {
	this.initialize(img.back);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Bitmap5 = function() {
	this.initialize(img.Bitmap5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,29);


(lib.mitsubishi7 = function() {
	this.initialize(img.mitsubishi7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,188);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Символ36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC00").s().p("Aivg1QAaALBCAgQArAUASAKQAIAFABgEQABgDAygqQAzgrAjggQAkggAQgDIhkCUQg5BUgVAlQgDgNiqivg");
	this.shape.setTransform(15.3,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ36, new cjs.Rectangle(-2.2,0,35.2,27), null);


(lib.Символ22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#09090A").s().p("AAXBEIAAg6IgtAAIAAA6IgaAAIAAiHIAaAAIAAA6IAtAAIAAg6IAaAAIAACHg");
	this.shape.setTransform(412.2,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#09090A").s().p("AAYBgIAAhdIgBAAIgtBdIgaAAIAAiHIAaAAIAABcIABAAIAthcIAZAAIAACHgAgahGQgJgKAAgPIAAgBIAUAAQAAAJAEAFQADAFAIAAQAIAAAEgFQAEgFAAgJIATAAIABABQABAPgLAKQgJAJgRAAQgPAAgLgJg");
	this.shape_1.setTransform(399.5,17.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#09090A").s().p("AgoA8QgKgLAAgTQAAgTAOgLQANgKAXAAIAVAAIAAgOQAAgNgFgHQgGgHgKAAQgJAAgFAGQgGAGABAKIgZAAIAAgBQgBgQANgMQAOgMATAAQAVAAANAMQAMAMAAAWIAAA+IABAQIADAOIgaAAIgCgLIgCgJQgFAKgJAGQgIAHgLAAQgSAAgKgLgAgSAMQgHAIAAAKQAAAKAGAGQAEAFAIAAQAJAAAIgGQAJgHACgJIAAgYIgVAAQgLAAgHAHg");
	this.shape_2.setTransform(387.1,20.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#09090A").s().p("AAdBEIAAh0IgiAAIAAAoQAAAngJATQgKASgYAAIgGAAIAAgUIAEAAQALAAAEgNQAFgMAAgfIAAg7IBUAAIAACHg");
	this.shape_3.setTransform(374.3,20.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#09090A").s().p("AAXBEIAAg6IgtAAIAAA6IgaAAIAAiHIAaAAIAAA6IAtAAIAAg6IAaAAIAACHg");
	this.shape_4.setTransform(362.2,20.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#09090A").s().p("AgnA0QgOgUAAgeIAAgDQAAgeAOgTQAPgUAYAAQAZAAAOAUQAPATAAAeIAAADQAAAegPAUQgOATgZAAQgYAAgPgTgAgUgkQgHAOAAAVIAAADQAAAWAHAOQAHANANAAQAPAAAGgNQAIgOAAgWIAAgDQgBgVgHgOQgHgOgOAAQgNAAgHAOg");
	this.shape_5.setTransform(349.5,20.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#09090A").s().p("AgoA8QgKgLAAgTQAAgTANgLQAOgKAXAAIAWAAIAAgOQgBgNgGgHQgFgHgKAAQgIAAgGAGQgFAGgBAKIgYAAIAAgBQgBgQANgMQAOgMATAAQAVAAAMAMQANAMAAAWIAAA+IABAQIADAOIgaAAIgCgLIgBgJQgGAKgJAGQgIAHgLAAQgSAAgKgLgAgSAMQgGAIgBAKQABAKAEAGQAFAFAIAAQAKAAAHgGQAJgHADgJIAAgYIgWAAQgLAAgHAHg");
	this.shape_6.setTransform(331.5,20.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#09090A").s().p("AAyBEIgeg6IgIAAIAAA6IgYAAIAAg6IgIAAIgdA6IghAAIAqhIIgng/IAgAAIAcA4IAHAAIAAg4IAYAAIAAA4IAHAAIAdg4IAgAAIgoA/IArBIg");
	this.shape_7.setTransform(316.9,20.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#09090A").s().p("AgyBgIAAi8IAVAAIADAQQAFgJAIgFQAIgFAKAAQAWAAAMAUQAMAUAAAhIAAACQAAAegMASQgMASgWAAQgJAAgHgEQgIgEgGgIIAABCgAgPhGQgGAFgEAIIAABDQAEAIAGAEQAGAEAIAAQANAAAHgMQAGgNAAgVIAAgCQAAgYgGgOQgHgPgNAAQgIAAgGAFg");
	this.shape_8.setTransform(302.2,23.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#09090A").s().p("AAYBEIAAhcIgBAAIgtBcIgaAAIAAiHIAaAAIAABcIABAAIAthcIAZAAIAACHg");
	this.shape_9.setTransform(289.3,20.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#09090A").s().p("AgmBQQgPgTAAgfIAAgDIAAgCIAAgBIAAgfQAAgmAOgSQANgSAagBQAPgBAIgEQAHgDAAgIIAUAAIAAAAQABAUgMAIQgMAIgYAAQgRABgJAJQgKAKABASIABABQAGgIAJgFQAJgFAKAAQAYAAAOATQANAUAAAdIAAADQAAAfgPATQgOATgZAAQgYAAgOgTgAgUgIQgHAOAAAVIAAADQAAAWAHAOQAHAOANAAQAOAAAHgOQAIgOgBgWIAAgDQABgWgIgNQgHgOgOAAQgOAAgGAOg");
	this.shape_10.setTransform(276.8,17.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#09090A").s().p("AAaBEIAAg0IgYAAIgZA0IgbAAIAdg4QgMgFgGgJQgGgKAAgNQAAgSAMgMQANgMAVAAIAyAAIAACHgAgOgpQgGAHAAAKQAAAJAGAHQAFAHAJAAIAaAAIAAgvIgZAAQgKAAgFAHg");
	this.shape_11.setTransform(258.1,20.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#09090A").s().p("AgoA8QgKgLAAgTQAAgTANgLQAOgKAXAAIAWAAIAAgOQAAgNgHgHQgFgHgKAAQgIAAgGAGQgFAGgBAKIgYAAIAAgBQgBgQANgMQANgMAVAAQAUAAAMAMQANAMAAAWIAAA+IABAQIADAOIgaAAIgCgLIgBgJQgGAKgJAGQgIAHgLAAQgSAAgKgLgAgSAMQgGAIAAAKQAAAKAEAGQAFAFAIAAQAKAAAIgGQAIgHADgJIAAgYIgWAAQgLAAgHAHg");
	this.shape_12.setTransform(246.1,20.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#09090A").s().p("AAXBEIAAg6IgtAAIAAA6IgaAAIAAiHIAaAAIAAA6IAtAAIAAg6IAaAAIAACHg");
	this.shape_13.setTransform(233.7,20.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#09090A").s().p("AgxBEIAAiHIAaAAIAAAyIAZAAQAWAAANAMQAMALAAATQAAATgMAMQgNAMgWAAgAgXAxIAZAAQALAAAGgHQAFgGAAgLQAAgJgFgHQgGgHgLAAIgZAAg");
	this.shape_14.setTransform(221.6,20.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#09090A").s().p("AAdBEIAAh0IgiAAIAAAoQAAAngKATQgKASgYAAIgEAAIAAgUIADAAQAMAAADgNQAEgMAAgfIAAg7IBVAAIAACHg");
	this.shape_15.setTransform(208.3,20.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#09090A").s().p("AAXBEIAAhcIgBAAIgsBcIgaAAIAAiHIAaAAIAABcIAAAAIAthcIAaAAIAACHg");
	this.shape_16.setTransform(196.2,20.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#09090A").s().p("AgnBQQgOgTAAgfIAAgDIAAgCIAAgBIAAgfQAAgmANgSQAOgSAbgBQAOgBAHgEQAIgDAAgIIAUAAIAAAAQABAUgMAIQgMAIgYAAQgRABgJAJQgJAKAAASIABABQAGgIAJgFQAKgFAJAAQAYAAANATQAOAUAAAdIAAADQAAAfgPATQgOATgZAAQgYAAgPgTgAgUgIQgIAOAAAVIAAADQAAAWAIAOQAHAOANAAQAOAAAHgOQAIgOAAgWIAAgDQAAgWgIgNQgHgOgOAAQgOAAgGAOg");
	this.shape_17.setTransform(183.7,17.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#09090A").s().p("AgmA0QgPgUAAgeIAAgDQAAgeAPgTQAOgUAYAAQAZAAAOAUQAPATAAAeIAAADQAAAegPAUQgOATgZAAQgYAAgOgTgAgUgkQgHAOAAAVIAAADQAAAWAHAOQAHANANAAQAPAAAGgNQAIgOgBgWIAAgDQAAgVgHgOQgHgOgOAAQgNAAgHAOg");
	this.shape_18.setTransform(171.1,20.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#09090A").s().p("AAqBEIAAhZIgBAAIghBZIgQAAIgghaIgBABIAABZIgZAAIAAiHIAfAAIAjBoIAAAAIAjhoIAhAAIAACHg");
	this.shape_19.setTransform(156.3,20.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#09090A").s().p("AgmA0QgPgUAAgeIAAgDQAAgeAPgTQAOgUAYAAQAZAAAPAUQAOATAAAeIAAADQAAAegOAUQgPATgZAAQgYAAgOgTgAgUgkQgHAOAAAVIAAADQAAAWAHAOQAHANANAAQAOAAAIgNQAGgOAAgWIAAgDQABgVgIgOQgHgOgOAAQgNAAgHAOg");
	this.shape_20.setTransform(141.6,20.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#09090A").s().p("AgMBEIAAh0IgmAAIAAgTIBlAAIAAATIgmAAIAAB0g");
	this.shape_21.setTransform(129.4,20.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#09090A").s().p("AgyBEIAAiHIAvAAQAWAAANAJQANAJAAATQAAAKgFAIQgGAHgKAEQANACAHAJQAHAIAAAMQAAATgNAKQgMAJgWAAgAgYAxIAcAAQAKAAAGgFQAFgFAAgLQAAgJgFgFQgGgGgKAAIgcAAgAgYgJIAXAAQAKAAAFgFQAGgFAAgJQAAgKgGgFQgGgFgLAAIgVAAg");
	this.shape_22.setTransform(117.6,20.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#09090A").s().p("AgoA8QgKgLAAgTQAAgTAOgLQANgKAXAAIAVAAIAAgOQAAgNgFgHQgGgHgKAAQgIAAgGAGQgGAGABAKIgZAAIAAgBQgBgQANgMQAOgMATAAQAVAAANAMQAMAMAAAWIAAA+IABAQIADAOIgaAAIgDgLIgBgJQgFAKgJAGQgIAHgLAAQgSAAgKgLgAgRAMQgIAIAAAKQAAAKAGAGQAEAFAIAAQAKAAAHgGQAJgHACgJIAAgYIgVAAQgLAAgGAHg");
	this.shape_23.setTransform(104.8,20.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#09090A").s().p("AAaBEIAAg0IgYAAIgZA0IgbAAIAdg4QgMgFgGgJQgGgKAAgNQAAgSAMgMQANgMAVAAIAyAAIAACHgAgOgpQgGAHAAAKQAAAJAGAHQAFAHAJAAIAaAAIAAgvIgZAAQgKAAgFAHg");
	this.shape_24.setTransform(86.4,20.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#09090A").s().p("AgoA8QgKgLAAgTQAAgTAOgLQANgKAXAAIAWAAIAAgOQgBgNgFgHQgGgHgKAAQgJAAgFAGQgFAGAAAKIgZAAIAAgBQgBgQANgMQAOgMATAAQAVAAAMAMQANAMAAAWIAAA+IABAQIADAOIgaAAIgCgLIgBgJQgGAKgJAGQgIAHgLAAQgSAAgKgLgAgSAMQgGAIgBAKQABAKAFAGQAEAFAIAAQAKAAAHgGQAJgHADgJIAAgYIgWAAQgLAAgHAHg");
	this.shape_25.setTransform(74.4,20.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#09090A").s().p("AgyBEIAAiHIAvAAQAWAAANAJQANAJAAATQAAAKgFAIQgGAHgKAEQANACAHAJQAHAIAAAMQAAATgNAKQgMAJgWAAgAgYAxIAcAAQAKAAAGgFQAFgFAAgLQAAgJgFgFQgGgGgKAAIgcAAgAgYgJIAXAAQAKAAAFgFQAGgFAAgJQAAgKgGgFQgGgFgLAAIgVAAg");
	this.shape_26.setTransform(62.3,20.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#09090A").s().p("AgyBgIAAi8IAVAAIADAQQAFgJAIgFQAIgFAKAAQAWAAAMAUQAMAUAAAhIAAACQAAAegMASQgMASgWAAQgJAAgHgEQgIgEgGgIIAABCgAgPhGQgGAFgEAIIAABDQAEAIAGAEQAGAEAIAAQANAAAHgMQAGgNAAgVIAAgCQAAgYgGgOQgHgPgNAAQgIAAgGAFg");
	this.shape_27.setTransform(49.6,23.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#09090A").s().p("AgjA0QgOgSAAgeIAAgFQAAgeAOgUQAPgTAWAAQAYAAAMARQAMAQAAAcIAAAOIhJAAQAAAUAIANQAHANAOAAQALAAAIgDQAIgDAHgHIAIAQQgHAHgLAFQgLAFgOAAQgZAAgPgTgAgOgoQgHAKgBARIAuAAIAAgDQAAgPgEgKQgHgJgLAAQgKAAgGAKg");
	this.shape_28.setTransform(37.3,20.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#09090A").s().p("AAkBcIAAijIhHAAIAACjIgaAAIAAi3IB7AAIAAC3g");
	this.shape_29.setTransform(23.4,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ22, new cjs.Rectangle(11.9,0,410.2,37.2), null);


(lib.Символ20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AggBSQgOgGgKgLQgJgMgGgQQgGgRAAgUQAAgTAGgRQAGgQAJgMQAKgLAOgGQAPgGARAAQASAAAPAGQAOAGAKALQAKAMAFAQQAGARAAATQAAAUgGARQgFAQgKAMQgKALgOAGQgPAGgSAAQgRAAgPgGgAgUg6QgJAFgGAIQgHAJgDALQgCAMAAANQAAAOACAMQADALAHAJQAGAIAJAFQAJAEALAAQAMAAAJgEQAJgFAGgIQAHgJACgLQAEgMAAgOQAAgNgEgMQgCgLgHgJQgGgIgJgFQgJgFgMAAQgLAAgJAFg");
	this.shape.setTransform(263.3,42.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNBTIAAiMIg6AAIAAgZICPAAIAAAZIg6AAIAACMg");
	this.shape_1.setTransform(246.5,42.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhFBTIAAilIBGAAQAeAAAPALQAQALgBAWQAAAMgFAHQgFAIgJAGQANAFAHAJQAIAJAAAPQAAAMgEAJQgDAJgJAHQgHAGgNAEQgMADgQAAgAgoA8IAqAAQAMAAAHgBQAIgCAEgEQAFgDACgFQACgFAAgGQAAgGgCgFQgCgFgFgDQgEgDgIgCQgHgCgMAAIgqAAgAgogMIAqAAQAOAAAIgGQAJgFAAgNQAAgGgCgFQgDgFgEgCQgDgDgFgBIgKgBIguAAg");
	this.shape_2.setTransform(230.2,42.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguBVQgJgDgHgGQgHgGgFgJQgEgJAAgMQAAgNAEgJQAFgJAHgHQAHgFAJgDQAJgEAJgBIAugGQAHAAAEgFQADgEAAgKQAAgPgJgHQgKgGgSAAQgTAAgJAIQgKAIgBAQIgbAAQABgQAFgKQAFgLAJgGQAKgHAMgDQAMgCAPAAQALAAAMACQALADAJAFQAJAGAFAIQAFAJAAANIAABgQAAAEADADQACACAFAAIAEAAIAFgBIAAAUIgHACIgJAAIgMgBQgGgBgDgDQgEgDgCgEIgDgMIgLALIgNAJQgHADgIACQgKACgLAAQgKAAgJgDgAAXADIgLACIgMACIgNACIgPADIgLAFQgFAEgDAEQgCAFAAAGQAAAHACAGQACAFAEAEQAEAEAGABQAFACAHAAIAKgBIAKgDIALgFIAKgIIAHgKQADgGAAgHIAAgag");
	this.shape_3.setTransform(212.6,42.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhBBTIAAilIAcAAIAAA+IAtAAQAOAAALAEQALAEAHAHQAIAFADAKQAFAJAAAMQAAAMgFAKQgDAKgIAGQgHAHgLAEQgLADgOAAgAglA8IAoAAIANgBQAHgCAEgDQAFgEADgFQACgGAAgIQAAgHgCgGQgDgFgFgEQgEgDgHgCIgQgCIglAAg");
	this.shape_4.setTransform(187.5,42.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNBTIAAiMIg6AAIAAgZICPAAIAAAZIg6AAIAACMg");
	this.shape_5.setTransform(170.7,42.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBVQgJgDgHgGQgHgGgFgJQgEgJAAgMQAAgNAEgJQAFgJAHgHQAHgFAJgDQAJgEAJgBIAugGQAHAAAEgFQADgEAAgKQAAgPgJgHQgKgGgSAAQgTAAgJAIQgKAIgBAQIgbAAQABgQAFgKQAFgLAJgGQAKgHAMgDQAMgCAPAAQALAAAMACQALADAJAFQAJAGAFAIQAFAJAAANIAABgQAAAEADADQACACAFAAIAEAAIAFgBIAAAUIgHACIgJAAIgMgBQgGgBgDgDQgEgDgCgEIgDgMIgLALIgNAJQgHADgIACQgKACgLAAQgKAAgJgDgAAXADIgLACIgMACIgNACIgPADIgLAFQgFAEgDAEQgCAFAAAGQAAAHACAGQACAFAEAEQAEAEAGABQAFACAHAAIAKgBIAKgDIALgFIAKgIIAHgKQADgGAAgHIAAgag");
	this.shape_6.setTransform(154.3,42.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhIB2IAAjmIAcAAIAAAWIABAAIAHgLQAEgEAGgFQAGgEAIgCQAIgCAJAAQANAAANAGQAMAEAKALQAJAKAGAPQAFAQAAAUQAAAagFARQgFASgKALQgJAMgOAFQgNAFgRAAQgHAAgHgCIgNgFIgKgIIgGgJIgBAAIAABUgAgUhYQgIAFgFAIQgGAJgDALQgCANAAANQAAAOACAMQADAKAGAIQAFAJAIAEQAJAFALAAQALAAAJgFQAIgEAGgJQAFgIADgKQADgMAAgOQAAgNgDgNQgDgLgFgJQgGgIgIgFQgJgFgLAAQgLAAgJAFg");
	this.shape_7.setTransform(136.7,45.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOB1QgIgBgIgEQgIgDgHgFQgIgGgGgJIgHgKIgFgNIgEgUIgCgaIABgVIAEgaIAGgZQAEgMAGgKQAGgJAIgHQAHgGAIgDQAIgEAKgCIATgCIAKAAIAJAAIAFgCIAEgDIACgFIAWAAIgBAGIgCAHIgEAHIgIAHIgEADIgFADIgIABIgNABIgMAAQgLABgJAEQgLAFgHAIQgHAIgFAMQgFALgCAOIAIgMQAFgGAHgFQAHgEAKgDQAKgDALAAQAOAAANAFQANAFAKAKQAKALAGAPQAFAOAAAUIgBAQIgDATQgDAKgFAKQgFAKgJAHQgJAIgMAFQgMAFgRAAgAgVgZQgIAFgGAJQgHAJgCAKQgEAMAAAMIABAMIACANIAFAOQADAGAGAGQAFAFAIAEQAIADAKAAQAMAAAIgEQAJgEAGgGQAFgHADgHIAEgPIABgNIABgJQAAgMgCgLQgDgKgGgIQgFgIgKgGQgJgFgNAAQgMAAgKAFg");
	this.shape_8.setTransform(118.6,39.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABBBTIAAilIAdAAIAAClgAhdBTIAAilIAdAAIAAA+IAxAAQAOAAAKAEQALAEAHAHQAIAFAEAKQADAJABAMQgBAMgDAKQgEAKgIAGQgHAHgLAEQgKADgOAAgAhAA8IAsAAIAOgBQAGgCAEgDQAEgEADgFQADgGAAgIQAAgHgDgGQgDgFgEgEQgFgDgGgCIgPgCIgqAAg");
	this.shape_9.setTransform(98.3,42.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhXByIAAjjIBSAAIAWAAIATADQAJADAIAEQAHAFAFAGQAGAHADAJQADAJABALIgCANQgCAHgEAGQgDAHgGAGQgFAFgJAEIAOAGQAIAEAFAGQAGAHAFAJQADAKAAANIgBAPQgDAIgEAIQgEAHgGAHQgFAHgKAFQgJAEgLADQgMADgPAAgAg4BXIA8AAQAPAAAKgCQALgDAFgFQAHgGADgHQADgHAAgJQAAgJgDgIQgDgHgHgFQgFgFgLgDQgKgDgPAAIg8AAgAg4gQIA4AAQAPAAAJgDQAKgDAEgFQAGgFABgGIACgPQAAgIgDgGQgCgGgGgFQgFgEgJgCQgJgDgNAAIg4AAg");
	this.shape_10.setTransform(76.7,39.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00CC00").s().p("A3qIIQitAAAAitIAAq1QAAitCtAAMAvWAAAQCsAAABCtIAAK1QgBCtisAAg");
	this.shape_11.setTransform(168.9,52);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgjBcQgQgHgLgNQgLgNgGgSQgGgTAAgWQAAgWAGgSQAGgSALgNQALgNAQgGQAQgIATABQAUgBAQAIQAQAGAMANQALANAGASQAFASAAAWQAAAWgFATQgGASgLANQgMANgQAHQgQAHgUAAQgTAAgQgHgAgWhBQgKAGgHAJQgHAJgEAOQgDANAAAOQAAAPADAOQAEAMAHAKQAHAKAKAEQAKAGAMAAQANAAALgGQAKgEAHgKQAHgKADgMQAEgOAAgPQAAgOgEgNQgDgOgHgJQgHgJgKgGQgLgFgNAAQgMAAgKAFg");
	this.shape_12.setTransform(274.3,41.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgPBdIAAidIhAAAIAAgcICfAAIAAAcIhAAAIAACdg");
	this.shape_13.setTransform(255.5,41.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhNBdIAAi5IBOAAQAiAAARANQARAMAAAZQAAANgHAIQgGAJgKAHQAPAFAIAKQAJAKAAARQAAANgEAKQgFAKgIAIQgJAHgOAEQgOAEgSAAgAgtBDIAvAAQANAAAIgCQAJgBAFgFQAFgDACgGQACgFAAgGQAAgHgCgGQgCgFgFgEQgFgEgJgCQgIgCgNAAIgvAAgAgtgOIAvAAQAQABAJgHQAKgGAAgOQAAgHgDgFQgCgGgFgCQgEgEgFgBIgMgCIgzAAg");
	this.shape_14.setTransform(237.4,41.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgzBfQgKgDgIgHQgIgHgFgKQgFgJAAgOQAAgOAFgLQAFgKAHgIQAIgFAKgEQALgEAKgBIAzgGQAIgCAEgEQAEgFAAgMQAAgQgLgIQgLgHgUAAQgVAAgKAJQgLAJgBASIgeAAQAAgRAHgMQAFgMALgHQAJgHAOgEQAOgCARAAQAMgBANADQAMADALAGQAJAGAHAKQAFAKAAAOIAABrQABAEACAEQACADAGAAIAEAAIAGgBIAAAVIgIACIgJABIgPgBQgGgBgEgDQgDgEgDgFIgDgNIgMANIgPAJQgIAEgKACQgKADgMAAQgLAAgKgEgAAaADIgNADIgNADIgPABIgQADIgNAHQgFADgDAGQgDAFAAAGQAAAIACAHQADAGAFAEQAEAEAGACQAHACAGAAIAMgBIALgEIAMgFIAMgJQAEgFAEgHQADgGAAgHIAAgdg");
	this.shape_15.setTransform(217.8,41.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhJBdIAAi5IAgAAIAABGIAyAAQAPAAAMAEQAMAEAJAIQAJAHAEAKQAEAKAAAOQAAAOgEAKQgEALgJAHQgJAIgMAEQgMAEgPAAgAgpBDIAsAAIAQgCQAHgBAFgEQAGgEADgGQACgGAAgJQAAgJgCgGQgEgGgFgDQgGgEgIgDIgRgCIgpAAg");
	this.shape_16.setTransform(189.6,41.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgPBdIAAidIhAAAIAAgcICfAAIAAAcIhAAAIAACdg");
	this.shape_17.setTransform(171,41.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgzBfQgKgDgIgHQgIgHgFgKQgFgJAAgOQAAgOAFgLQAFgKAHgIQAIgFAKgEQAKgEALgBIAzgGQAHgCAFgEQAEgFAAgMQAAgQgLgIQgLgHgUAAQgVAAgKAJQgLAJgBASIgeAAQAAgRAHgMQAFgMALgHQAJgHAOgEQAOgCARAAQAMgBANADQAMADAKAGQAKAGAHAKQAFAKABAOIAABrQAAAEACAEQACADAGAAIAEAAIAGgBIAAAVIgIACIgJABIgPgBQgFgBgFgDQgEgEgCgFIgDgNIgMANIgPAJQgIAEgKACQgKADgMAAQgLAAgKgEgAAaADIgMADIgOADIgPABIgQADIgNAHQgFADgDAGQgDAFAAAGQAAAIACAHQADAGAFAEQAEAEAGACQAGACAIAAIALgBIALgEIANgFIALgJQAEgFAEgHQACgGAAgHIAAgdg");
	this.shape_18.setTransform(152.6,41.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhRCEIAAkCIAgAAIAAAZIABAAIAIgLQAFgHAHgDQAGgFAJgCQAJgDAKABQAPgBAOAGQANAGALALQAKAMAHARQAGASAAAWQAAAdgGATQgGAUgKAMQgLANgPAGQgPAGgTAAQgIAAgIgDIgOgGIgLgIIgHgKIgBAAIAABegAgWhjQgJAFgGAKQgGAKgDANQgDANAAAQQAAAPADANQADALAGAKQAGAKAJAEQAJAGANAAQAMAAAKgGQAKgEAGgKQAGgKADgLQADgNAAgPQAAgQgDgNQgDgNgGgKQgGgKgKgFQgKgFgMAAQgNAAgJAFg");
	this.shape_19.setTransform(132.9,45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgPCDQgJgCgJgEQgJgDgJgGQgIgHgHgJIgHgLIgGgQIgFgVIgBgdIABgYIADgdIAHgcQAFgOAGgKQAIgLAIgHQAIgHAJgEQAJgEAKgCIAWgCIALAAIAKgBIAGgCIAEgDIADgGIAYAAIgBAHIgCAIIgFAIIgIAIIgFADIgGADIgJACIgOABIgNAAQgNAAgLAFQgKAFgJAJQgIAJgFANQgGANgCAQIAJgOQAFgGAIgFQAIgGALgDQALgDANAAQAQAAAPAFQAOAGALALQALAMAGARQAGAQAAAXIgBARIgEAWQgDALgGAKQgFALgKAJQgKAJgNAFQgOAFgUABgAgXgbQgKAFgHAKQgHAKgDALQgDANAAAOIAAANIADAOIAFAQQAEAIAGAFQAGAHAJADQAJAEALAAQAOAAAJgFQAJgEAHgHQAGgHADgJIAFgQIABgOIABgLQAAgNgDgMQgDgLgGgJQgHgKgKgFQgKgGgPAAQgNAAgLAGg");
	this.shape_20.setTransform(112.7,38.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABJBdIAAi5IAgAAIAAC5gAhoBdIAAi5IAgAAIAABGIA4AAQAPAAALAEQAMAEAJAIQAIAHAEAKQAFAKAAAOQAAAOgFAKQgEALgIAHQgJAIgMAEQgLAEgPAAgAhIBDIAyAAIAPgCQAHgBAFgEQAFgEADgGQADgGAAgJQAAgJgDgGQgDgGgGgDQgEgEgIgDIgRgCIgvAAg");
	this.shape_21.setTransform(90,41.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhhCAIAAj/IBbAAIAZABIAWAEQAJACAIAFQAIAFAHAIQAGAHAEAKQADAKAAAMIgCAPQgBAIgEAHQgEAHgHAGQgGAHgKAEIAQAHQAIAEAHAHQAGAIAFAKQAEALAAAOIgCARQgCAJgEAIQgFAJgHAIQgHAHgJAFQgKAGgNADQgNADgRABgAg/BhIBDAAQARAAALgCQAMgEAHgFQAHgHADgIQADgHAAgLQAAgKgDgIQgDgIgHgGQgHgGgMgDQgLgDgRAAIhDAAgAg/gSIA/AAQAQAAALgDQAKgDAGgGQAFgFACgIIACgQQAAgJgDgHQgCgHgHgEQgGgFgKgDQgKgDgOAAIg/AAg");
	this.shape_22.setTransform(66,38.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00CC33").s().p("A3qIIQitAAAAitIAAq1QAAitCtAAMAvWAAAQCsAAABCtIAAK1QgBCtisAAg");
	this.shape_23.setTransform(168.9,52,1.116,1.116);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,104);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Bitmap5();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ17, new cjs.Rectangle(0,0,300,29), null);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC00").s().p("AAYA2IgIgbIgfAAIgIAbIgPAAIAghrIANAAIAgBrgAANAPIgNgrIAAAAIgMArIAZAAg");
	this.shape.setTransform(135.6,9.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AAVA2IAAgwIgpAAIAAAwIgPAAIAAhrIAPAAIAAAxIApAAIAAgxIAPAAIAABrg");
	this.shape_1.setTransform(126.9,9.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00CC00").s().p("AgcA2IAAhrIA5AAIAAAMIgqAAIAAAiIAjAAIAAALIgjAAIAAAmIAqAAIAAAMg");
	this.shape_2.setTransform(118.8,9.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00CC00").s().p("AgtBDIAAgmIAGAAQAHAAAEgNQAEgOABgbIACgpIA4AAIAABfIALAAIAAAmIgPAAIAAgaIg9AAIAAAagAgIgZQgBAUgDAMQgDAOgFAIIAnAAIAAhTIgZAAg");
	this.shape_3.setTransform(110.1,11);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00CC00").s().p("AAVBFIAAhOIgBAAIgoBOIgPAAIAAhrIAPAAIAABOIABAAIAohOIAPAAIAABrgAgPg2QgFgFABgIIAAgBIALAAQgBAFADADQADADADAAQAFAAADgDQACgDAAgFIALAAIAAABQABAIgGAFQgGAGgKAAQgIAAgHgGg");
	this.shape_4.setTransform(100.7,8.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00CC00").s().p("AgaAtQgLgLAAgTIAAgdQAAgTALgKQAKgLAQAAQARAAALALQAKAKAAATIAAAdQAAATgKALQgLAKgRAAQgQAAgKgKgAgQgjQgGAHAAAOIAAAdQAAAOAGAHQAGAIAKAAQALAAAGgIQAGgHAAgOIAAgdQAAgOgGgHQgGgHgLAAQgKAAgGAHg");
	this.shape_5.setTransform(91.5,9.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00CC00").s().p("AghA2IAAhrIAiAAQAPAAAJAJQAJAJAAAPQAAAPgJAHQgJAJgPAAIgTAAIAAArgAgSAAIATAAQAJAAAEgFQAFgGAAgJQAAgJgFgGQgEgGgJAAIgTAAg");
	this.shape_6.setTransform(83.1,9.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00CC00").s().p("AAVA2IAAhfIgpAAIAABfIgPAAIAAhrIBHAAIAABrg");
	this.shape_7.setTransform(74.1,9.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00CC00").s().p("AAYA2IgIgbIgfAAIgIAbIgPAAIAghrIANAAIAgBrgAANAPIgNgrIAAAAIgMArIAZAAg");
	this.shape_8.setTransform(62,9.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00CC00").s().p("AARA2IgegxIgHAAIAAAxIgPAAIAAhrIAPAAIAAAvIAGAAIAdgvIASAAIgiAzIAlA4g");
	this.shape_9.setTransform(54.2,9.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00CC00").s().p("AghA2IAAhrIAiAAQAPAAAJAJQAJAJAAAPQAAAPgJAHQgJAJgPAAIgTAAIAAArgAgSAAIATAAQAJAAAEgFQAFgGAAgJQAAgJgFgGQgEgGgJAAIgTAAg");
	this.shape_10.setTransform(45.6,9.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00CC00").s().p("AgcA2IAAhrIA5AAIAAAMIgqAAIAAAiIAjAAIAAALIgjAAIAAAmIAqAAIAAAMg");
	this.shape_11.setTransform(37.8,9.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00CC00").s().p("AghA2IAAhrIAeAAQAOAAAJAIQAJAHAAAOQAAAIgEAGQgEAFgHADQAKACAFAGQAFAHAAAKQAAAPgJAIQgIAIgPAAgAgSAqIAUAAQAIAAAEgEQAFgFAAgKQAAgIgFgGQgEgFgIAAIgBAAIgTAAgAgSgGIARAAQAGAAAEgFQAEgEAAgIQAAgJgEgFQgFgEgHAAIgPAAg");
	this.shape_12.setTransform(30,9.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00CC00").s().p("AgaAtQgLgLAAgTIAAgdQAAgTALgKQAKgLAQAAQARAAALALQAKAKAAATIAAAdQAAATgKALQgLAKgRAAQgQAAgKgKgAgQgjQgGAHAAAOIAAAdQAAAOAGAHQAGAIAKAAQALAAAGgIQAGgHAAgOIAAgdQAAgOgGgHQgGgHgLAAQgKAAgGAHg");
	this.shape_13.setTransform(21.1,9.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00CC00").s().p("AghA2IAAhrIAiAAQAPAAAJAJQAJAJAAAPQAAAPgJAHQgJAJgPAAIgTAAIAAArgAgSAAIATAAQAJAAAEgFQAFgGAAgJQAAgJgFgGQgEgGgJAAIgTAAg");
	this.shape_14.setTransform(12.7,9.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00CC00").s().p("AAVA2IAAhfIgpAAIAABfIgPAAIAAhrIBHAAIAABrg");
	this.shape_15.setTransform(3.6,9.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15, new cjs.Rectangle(-2,0,142.8,19.7), null);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC00").s().p("AgrBvIgLgDIAFgeIAEAAIACAAQAKAAAEgFQAFgFACgIIAEgMIgwieIAtAAIAUBeIAAABIABAAIAWhfIAtAAIg3C1QgGARgJAMQgKALgVAAg");
	this.shape.setTransform(157.4,14.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AALBPIgXg7IgMAAIAAA7IgqAAIAAidIAqAAIAAA8IAJAAIAZg8IA1AAIgrBHIAAABIABAAIAtBVg");
	this.shape_1.setTransform(143.9,10.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00CC00").s().p("AATBPIAAgyIgHABIgHAAQgfAAgRgOQgRgPAAgeIAAgxIAqAAIAAAxQAAAQAFAGQAFAGANAAIAHAAIAHgCIAAhLIAqAAIAACdg");
	this.shape_2.setTransform(128.2,10.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00CC00").s().p("AgvA8QgRgWAAgkIAAgCQAAgkARgXQARgWAeAAQAfAAARAWQARAXAAAkIAAACQAAAkgRAWQgRAWgfAAQgeAAgRgWgAgRgjQgGANAAAWIAAACQAAAWAGANQAFANAMAAQANAAAFgNQAGgNAAgWIAAgCQAAgWgGgNQgFgOgNAAQgMAAgFAOg");
	this.shape_3.setTransform(113.5,10.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00CC00").s().p("Ag+BvIAAjaIAmAAIACAQQAFgJAIgFQAJgFAJAAQAaAAAOAXQAOAXAAAlIAAADQAAAigOAWQgOAVgZAAQgKAAgHgEQgIgEgGgHIAABJgAgNhKQgFAEgDAGIAABKQADAFAFADQAGADAHAAQALAAAFgMQAFgLAAgWIAAgDQAAgXgFgOQgGgOgKAAQgHAAgGAEg");
	this.shape_4.setTransform(99,13.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00CC00").s().p("AgqA8QgRgWAAgkIAAgDQAAgjARgXQAQgWAeAAQAaAAAPAQQAPARAAAcIAAAAIgmAAQAAgNgEgIQgFgIgJAAQgMAAgFANQgFANAAAWIAAADQAAAWAFANQAFANAMAAQAJAAAFgGQAEgHAAgMIAmAAIAAABQAAAZgPAQQgQAPgZAAQgeAAgQgWg");
	this.shape_5.setTransform(84.7,10.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00CC00").s().p("AgqA8QgRgWAAgkIAAgDQAAgjARgXQAQgWAeAAQAaAAAPAQQAPARAAAcIAAAAIgmAAQAAgNgEgIQgFgIgJAAQgMAAgFANQgFANAAAWIAAADQAAAWAFANQAFANAMAAQAJAAAFgGQAEgHAAgMIAmAAIAAABQAAAZgPAQQgQAPgZAAQgeAAgQgWg");
	this.shape_6.setTransform(71.2,10.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00CC00").s().p("AgzBGQgMgNAAgWQAAgXAQgMQAPgNAeAAIARAAIAAgNQAAgMgEgGQgFgHgHAAQgIAAgDAFQgEAGgBAJIgoAAIAAgBQAAgUAQgPQAQgOAZAAQAaAAAPAOQAQAPAAAaIAABAIACAVIAEAUIgoAAIgFgLIgCgNQgFAMgIAIQgIAHgNAAQgVAAgMgMgAgRAQQgEAHAAAKQAAAIADAGQAFAFAGAAQAIAAAFgFQAHgFACgIIAAgYIgRAAQgKAAgFAGg");
	this.shape_7.setTransform(57.5,10.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00CC00").s().p("Ag+BvIAAjaIAmAAIACAQQAFgJAIgFQAJgFAJAAQAaAAAOAXQAOAXAAAlIAAADQAAAigOAWQgOAVgZAAQgKAAgHgEQgIgEgGgHIAABJgAgNhKQgFAEgDAGIAABKQADAFAFADQAGADAHAAQALAAAFgMQAFgLAAgWIAAgDQAAgXgFgOQgGgOgKAAQgHAAgGAEg");
	this.shape_8.setTransform(43.4,13.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00CC00").s().p("Ag9BPIAAidIA6AAQAbAAAPALQAQALAAAWQAAALgHAJQgHAJgMAEQAQADAJAJQAIAKAAANQAAAXgOALQgPALgcAAgAgUAvIAZAAQAIAAAEgEQAEgEAAgJQAAgIgDgFQgEgEgJAAIgZAAgAgUgNIASAAQAIAAAEgEQADgEAAgIQAAgJgDgEQgFgEgIAAIgRAAg");
	this.shape_9.setTransform(22.2,10.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00CC00").s().p("AATBPIAAhYIAAAAIglBYIgqAAIAAidIAqAAIAABYIAAAAIAlhYIAqAAIAACdg");
	this.shape_10.setTransform(0.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ14, new cjs.Rectangle(-9,-11,175.3,39.2), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC00").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape.setTransform(499,20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00CC00").s().p("AATBPIAAg+IglAAIAAA+IgqAAIAAidIAqAAIAABAIAlAAIAAhAIAqAAIAACdg");
	this.shape_1.setTransform(484.7,20.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00CC00").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape_2.setTransform(470.5,20.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00CC00").s().p("AAeBqIAAg1IhkAAIAAieIApAAIAAB+IAmAAIAAh+IApAAIAAB+IAWAAIAABVg");
	this.shape_3.setTransform(456,23.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00CC00").s().p("AAUByIAAhZIgBAAIglBZIgqAAIAAieIAqAAIAABYIAAAAIAmhYIApAAIAACegAghhRQgMgMAAgTIABgBIAeAAQAAAIADAFQAEAFAIAAQAHAAAEgFQADgFAAgIIAfAAIABABQAAATgMAMQgOALgUAAQgWAAgMgLg");
	this.shape_4.setTransform(433.6,17.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00CC00").s().p("AgvA8QgRgWAAgkIAAgCQAAgkARgXQARgWAeAAQAfAAARAWQARAXAAAkIAAACQAAAkgRAWQgRAWgfAAQgeAAgRgWgAgRgjQgGANAAAWIAAACQAAAWAGANQAFANAMAAQANAAAFgNQAGgNAAgWIAAgCQAAgWgGgNQgFgOgNAAQgMAAgFAOg");
	this.shape_5.setTransform(418.8,20.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00CC00").s().p("AATBPIAAg+IglAAIAAA+IgqAAIAAidIAqAAIAABAIAlAAIAAhAIAqAAIAACdg");
	this.shape_6.setTransform(404,20.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00CC00").s().p("Ag+BPIAAidIAqAAIAAAzIAWAAQAcAAAQAPQARAOAAAXQAAAZgRAOQgQAPgcAAgAgUAvIAWAAQAJAAAFgGQAFgGAAgKQAAgJgFgGQgFgGgJAAIgWAAg");
	this.shape_7.setTransform(389.8,20.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00CC00").s().p("AAZBPIAAh9IgaAAIAAAkQgBAugNAWQgNAVgfAAIgFAAIgBghIADAAQANAAADgLQAEgMgBghIAAhEIBuAAIAACdg");
	this.shape_8.setTransform(374.1,20.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00CC00").s().p("AgzBGQgLgNAAgWQAAgXAPgMQAPgNAfAAIARAAIAAgNQAAgMgFgGQgFgHgHAAQgHAAgFAFQgDAGAAAJIgpAAIAAgBQgBgUARgPQAQgOAaAAQAZAAAPAOQAQAPAAAaIAABAIABAVIAGAUIgqAAIgDgLIgDgNQgFAMgJAIQgHAHgMAAQgXAAgLgMgAgQAQQgFAHgBAKQAAAIAFAGQADAFAHAAQAHAAAHgFQAGgFADgIIAAgYIgRAAQgLAAgEAGg");
	this.shape_9.setTransform(360.3,20.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00CC00").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape_10.setTransform(346.5,20.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00CC00").s().p("Ag+BvIAAjaIAmAAIACAQQAFgJAIgFQAJgFAJAAQAaAAAOAXQAOAXAAAlIAAADQAAAigOAWQgOAVgZAAQgKAAgHgEQgIgEgGgHIAABJgAgNhKQgFAEgDAGIAABKQADAFAFADQAGADAHAAQALAAAFgMQAFgLAAgWIAAgDQAAgXgFgOQgGgOgKAAQgHAAgGAEg");
	this.shape_11.setTransform(332.5,23.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00CC00").s().p("AgvA8QgRgWAAgkIAAgCQAAgkARgXQARgWAeAAQAfAAARAWQARAXAAAkIAAACQAAAkgRAWQgRAWgfAAQgeAAgRgWgAgRgjQgGANAAAWIAAACQAAAWAGANQAFANAMAAQANAAAFgNQAGgNAAgWIAAgCQAAgWgGgNQgFgOgNAAQgMAAgFAOg");
	this.shape_12.setTransform(310.8,20.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00CC00").s().p("AAUBPIAAh9IgnAAIAAB9IgpAAIAAidIB5AAIAACdg");
	this.shape_13.setTransform(296.1,20.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgvA8QgRgWAAgkIAAgCQAAgkARgXQARgWAeAAQAfAAARAWQARAXAAAkIAAACQAAAkgRAWQgRAWgfAAQgeAAgRgWgAgRgjQgGANAAAWIAAACQAAAWAGANQAFANAMAAQANAAAFgNQAGgNAAgWIAAgCQAAgWgGgNQgFgOgNAAQgMAAgFAOg");
	this.shape_14.setTransform(274.7,20.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgUBPIAAh9IgqAAIAAggIB9AAIAAAgIgrAAIAAB9g");
	this.shape_15.setTransform(260.6,20.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag9BPIAAidIA7AAQAaAAAPALQAPALAAAWQAAALgGAJQgHAJgNAEQARADAJAJQAIAKAAANQAAAXgPALQgOALgcAAgAgTAvIAYAAQAJAAADgEQAEgEAAgJQAAgIgEgFQgDgEgJAAIgYAAgAgTgNIASAAQAHAAADgEQAEgEABgIQgBgJgEgEQgEgEgHAAIgRAAg");
	this.shape_16.setTransform(246.7,20.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgzBGQgMgNAAgWQAAgXAQgMQAPgNAfAAIARAAIAAgNQgBgMgEgGQgEgHgIAAQgHAAgEAFQgFAGAAAJIgnAAIAAgBQgBgUAQgPQAQgOAZAAQAaAAAQAOQAPAPAAAaIAABAIACAVIAEAUIgoAAIgFgLIgCgNQgFAMgJAIQgHAHgNAAQgWAAgLgMgAgRAQQgEAHAAAKQAAAIADAGQAEAFAHAAQAHAAAHgFQAGgFADgIIAAgYIgRAAQgLAAgFAGg");
	this.shape_17.setTransform(231.9,20.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgrBvIgLgDIAFgeIAEAAIACAAQAKAAAEgFQAFgFACgIIAEgMIgwieIAtAAIAUBeIAAABIABAAIAWhfIAtAAIg3C1QgGARgJAMQgKALgVAAg");
	this.shape_18.setTransform(211.5,24.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("Ag0B0IBAjnIApAAIhADng");
	this.shape_19.setTransform(199.3,19.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgvBdQgRgWAAgkIAAgoQAAgxAPgVQAPgVAhgCQAPAAAIgDQAHgFAAgJIAgAAIAAABQABAcgPALQgOAKggABQgRABgJAIQgJAJABAOIABABQAGgIAKgEQAKgFAJAAQAeAAAQAWQAQAXAAAjIAAADQAAAkgRAWQgRAXgfAAQgeAAgRgXgAgRgCQgGAMAAAWIAAADQAAAXAGANQAFAMAMAAQANAAAGgMQAFgNAAgXIAAgDQAAgWgFgMQgGgOgNAAQgMAAgFAOg");
	this.shape_20.setTransform(186.9,17.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape_21.setTransform(166.2,20.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AA5BPIAAidIAqAAIAACdgAhiBPIAAidIAqAAIAAAzIAWAAQAdAAAPAPQARAOAAAXQAAAZgRAOQgPAPgdAAgAg4AvIAWAAQAKAAAFgGQAFgGAAgKQAAgJgFgGQgFgGgKAAIgWAAg");
	this.shape_22.setTransform(149,20.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AATBPIAAg+IglAAIAAA+IgqAAIAAidIAqAAIAABAIAlAAIAAhAIAqAAIAACdg");
	this.shape_23.setTransform(129.9,20.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AATBPIAAg+IglAAIAAA+IgqAAIAAidIAqAAIAABAIAlAAIAAhAIAqAAIAACdg");
	this.shape_24.setTransform(115.1,20.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape_25.setTransform(101,20.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("Ag+BvIAAjaIAmAAIACAQQAFgJAIgFQAJgFAJAAQAaAAAOAXQAOAXAAAlIAAADQAAAigOAWQgOAVgZAAQgKAAgHgEQgIgEgGgHIAABJgAgNhKQgFAEgDAGIAABKQADAFAFADQAGADAHAAQALAAAFgMQAFgLAAgWIAAgDQAAgXgFgOQgGgOgKAAQgHAAgGAEg");
	this.shape_26.setTransform(87,23.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgqA9QgSgWAAgiIAAgFQAAgkARgXQAQgWAeAAQAcAAAPATQAPATAAAhIAAAWIhPAAQABARAHALQAGAKAOAAQAMAAAJgDQAIgDAJgGIALAaQgIAIgPAFQgOAFgRAAQgeAAgRgVgAgMgoQgFAKgBAPIAmAAIAAgDQAAgPgEgIQgEgIgJAAQgKAAgFAJg");
	this.shape_27.setTransform(72.5,20.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("Ag9BPIAAidIA7AAQAaAAAPALQAPALAAAWQAAALgGAJQgHAJgNAEQARADAIAJQAJAKAAANQAAAXgPALQgOALgcAAgAgTAvIAYAAQAIAAAEgEQAEgEAAgJQAAgIgEgFQgDgEgJAAIgYAAgAgTgNIASAAQAHAAADgEQAFgEAAgIQAAgJgFgEQgEgEgHAAIgRAAg");
	this.shape_28.setTransform(58.7,20.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgvA8QgRgWAAgkIAAgCQAAgkARgXQARgWAeAAQAfAAARAWQARAXAAAkIAAACQAAAkgRAWQgRAWgfAAQgeAAgRgWgAgRgjQgGANAAAWIAAACQAAAWAGANQAFANAMAAQANAAAFgNQAGgNAAgWIAAgCQAAgWgGgNQgFgOgNAAQgMAAgFAOg");
	this.shape_29.setTransform(43.5,20.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("Ag+BvIAAjaIAmAAIACAQQAFgJAIgFQAJgFAJAAQAaAAAOAXQAOAXAAAlIAAADQAAAigOAWQgOAVgZAAQgKAAgHgEQgIgEgGgHIAABJgAgNhKQgFAEgDAGIAABKQADAFAFADQAGADAHAAQALAAAFgMQAFgLAAgWIAAgDQAAgXgFgOQgGgOgKAAQgHAAgGAEg");
	this.shape_30.setTransform(29,23.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAjBrIAAi0IhFAAIAAC0IgoAAIAAjVICVAAIAADVg");
	this.shape_31.setTransform(12.2,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13, new cjs.Rectangle(1,-1,507,39.2), null);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AAoBuIgNgvIg2AAIgMAvIgtAAIA/jbIArAAIA/DbgAATAdIgThFIAAAAIgSBFIAlAAg");
	this.shape.setTransform(132.3,19.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AAXBuIguhcIgLAAIAABcIgrAAIAAjbIArAAIAABaIAJAAIAthaIA1AAIg/BlIBEB2g");
	this.shape_1.setTransform(115.9,19.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AhIBuIAAjbIBJAAQAhAAATATQAUAUAAAfQAAAggUASQgTATghAAIgeAAIAABQgAgdgCIAeAAQAOAAAIgKQAHgLAAgPQAAgRgHgKQgIgLgOAAIgeAAg");
	this.shape_2.setTransform(98.1,19.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("Ag9BuIAAjbIB6AAIAAAhIhPAAIAAA5IBCAAIAAAgIhCAAIAABAIBQAAIAAAhg");
	this.shape_3.setTransform(82,19.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AhHBuIAAjbIA/AAQAhAAAUAPQATAPAAAeQAAAQgHAMQgHAMgOAGQASADAJAOQAJANAAATQAAAggSAQQgSAQgiAAgAgdBNIAfAAQANAAAIgIQAHgIAAgPQAAgQgHgIQgGgJgOAAIgCAAIgeAAgAgdgQIAXAAQANAAAHgIQAHgHAAgOQAAgQgHgHQgIgIgOAAIgVAAg");
	this.shape_4.setTransform(65.8,19.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("Ag6BcQgVgWAAgnIAAg9QAAgmAVgWQAWgWAkAAQAkAAAWAWQAWAWAAAmIAAA9QAAAngWAWQgWAVgkAAQgkAAgWgVgAgbhCQgKAMAAAYIAAA9QAAAYAKANQAJAMASAAQASAAAKgMQAKgNAAgYIAAg9QAAgYgKgMQgKgNgSAAQgSAAgJANg");
	this.shape_5.setTransform(47.6,19.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AhIBuIAAjbIBJAAQAhAAATATQAUAUAAAfQAAAggUASQgTATghAAIgeAAIAABQgAgdgCIAeAAQAOAAAIgKQAHgLAAgPQAAgRgHgKQgIgLgOAAIgeAAg");
	this.shape_6.setTransform(30,19.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("AAjBuIAAi6IhGAAIAAC6IgqAAIAAjbICbAAIAADbg");
	this.shape_7.setTransform(11.5,19.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ10, new cjs.Rectangle(0,0,143.1,40.3), null);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A70117").ss(1,1,1).p("AAAt6IAAb1");
	this.shape.setTransform(0,89.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ9, new cjs.Rectangle(-1,-1,2,180.2), null);


(lib.Символ7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.mitsubishi7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.872,0.872);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7, new cjs.Rectangle(0,0,436,164), null);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoRR5MAAAgjxIQiAAMAAAAjxg");
	mask.setTransform(376,114.5);

	// mitsubishi7.png
	this.instance = new lib.mitsubishi7();
	this.instance.parent = this;
	this.instance.setTransform(0,44,0.872,0.872);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6, new cjs.Rectangle(323.1,44,105.9,164), null);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoRR5MAAAgjxIQjAAMAAAAjxg");
	mask.setTransform(270,114.5);

	// mitsubishi7.png
	this.instance = new lib.mitsubishi7();
	this.instance.parent = this;
	this.instance.setTransform(0,44,0.872,0.872);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ5, new cjs.Rectangle(217,44,106,164), null);


(lib.Символ4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoRR5MAAAgjxIQjAAMAAAAjxg");
	mask.setTransform(58,114.5);

	// mitsubishi7.png
	this.instance = new lib.mitsubishi7();
	this.instance.parent = this;
	this.instance.setTransform(0,44,0.872,0.872);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4, new cjs.Rectangle(5.1,44,105.9,164), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoRR5MAAAgjxIQjAAMAAAAjxg");
	mask.setTransform(164,114.5);

	// mitsubishi7.png
	this.instance = new lib.mitsubishi7();
	this.instance.parent = this;
	this.instance.setTransform(0,44,0.872,0.872);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ3, new cjs.Rectangle(111,44,106,164), null);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.back();
	this.instance.parent = this;
	this.instance.setTransform(-238,476,0.476,0.476);

	this.instance_1 = new lib.back();
	this.instance_1.parent = this;
	this.instance_1.setTransform(476,476,0.476,0.476);

	this.instance_2 = new lib.back();
	this.instance_2.parent = this;
	this.instance_2.setTransform(238,476,0.476,0.476);

	this.instance_3 = new lib.back();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,476,0.476,0.476);

	this.instance_4 = new lib.back();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-238,238,0.476,0.476);

	this.instance_5 = new lib.back();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-238,0,0.476,0.476);

	this.instance_6 = new lib.back();
	this.instance_6.parent = this;
	this.instance_6.setTransform(476,238,0.476,0.476);

	this.instance_7 = new lib.back();
	this.instance_7.parent = this;
	this.instance_7.setTransform(476,0,0.476,0.476);

	this.instance_8 = new lib.back();
	this.instance_8.parent = this;
	this.instance_8.setTransform(238,238,0.476,0.476);

	this.instance_9 = new lib.back();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,238,0.476,0.476);

	this.instance_10 = new lib.back();
	this.instance_10.parent = this;
	this.instance_10.setTransform(238,0,0.476,0.476);

	this.instance_11 = new lib.back();
	this.instance_11.parent = this;
	this.instance_11.setTransform(0,0,0.476,0.476);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol24, new cjs.Rectangle(-238,0,952,714), null);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.instance = new lib.Символ20();
	this.instance.parent = this;
	this.instance.setTransform(168.8,34.7,1,1,0,0,0,168.8,52);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ18, new cjs.Rectangle(-19.5,-23.3,376.9,116.1), null);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ10();
	this.instance.parent = this;
	this.instance.setTransform(32.5,9.9,0.488,0.488,0,0,0,66.5,20.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ12, new cjs.Rectangle(0,0,69.8,19.7), null);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ12();
	this.instance.parent = this;
	this.instance.setTransform(32.5,9.9,1,1,0,0,0,32.5,9.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.328},4).to({alpha:1},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69.8,19.7);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ7();
	this.instance.parent = this;
	this.instance.setTransform(218,82,1,1,0,0,0,218,82);
	this.instance.filters = [new cjs.ColorMatrixFilter(new cjs.ColorMatrix(0, 0, -100, 0))];
	this.instance.cache(-2,-2,440,168);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ8, new cjs.Rectangle(0,0,440,167), null);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_88 = new cjs.Graphics().p("Ah6AAIAAhcIDKAAIArC5g");
	var mask_graphics_89 = new cjs.Graphics().p("AgCAOIiLiJICIAeICTDZg");
	var mask_graphics_90 = new cjs.Graphics().p("AhdheIhDg9IEWC6IArB9g");
	var mask_graphics_91 = new cjs.Graphics().p("AjQheIAAhcIGhDoIg6CNg");
	var mask_graphics_92 = new cjs.Graphics().p("AewEGIAAhbIGiDpIg6CNg");
	var mask_graphics_93 = new cjs.Graphics().p("AeOEGIAAhbIHmCVIh9Dhg");
	var mask_graphics_94 = new cjs.Graphics().p("AfvE+IiMiLIItAAIjEF2g");
	var mask_graphics_95 = new cjs.Graphics().p("AlYghIAAhcIKxh7IlKHxg");
	var mask_graphics_133 = new cjs.Graphics().p("AlYghIAAhcIKxh7IlKHxg");
	var mask_graphics_139 = new cjs.Graphics().p("AlYghIAAhcIKxh7IlKHxg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(88).to({graphics:mask_graphics_88,x:432.4,y:69.4}).wait(1).to({graphics:mask_graphics_89,x:439.4,y:76.3}).wait(1).to({graphics:mask_graphics_90,x:446.4,y:83.3}).wait(1).to({graphics:mask_graphics_91,x:456.3,y:90.3}).wait(1).to({graphics:mask_graphics_92,x:238.6,y:54.5}).wait(1).to({graphics:mask_graphics_93,x:242,y:54.5}).wait(1).to({graphics:mask_graphics_94,x:244.8,y:55.3}).wait(1).to({graphics:mask_graphics_95,x:469.9,y:84.1}).wait(38).to({graphics:mask_graphics_133,x:469.9,y:84.1}).wait(6).to({graphics:mask_graphics_139,x:469.9,y:84.1}).wait(211));

	// Слой 14
	this.instance = new lib.Символ36();
	this.instance.parent = this;
	this.instance.setTransform(470.1,85.1,1.552,1.552,0,0,0,16.4,13.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(88).to({_off:false},0).wait(45).to({alpha:0},6).to({_off:true},1).wait(210));

	// Слой 11
	this.instance_1 = new lib.Символ9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(10,75,1,1,0,0,0,0,89);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({x:431},54).to({_off:true},1).wait(261));

	// Слой 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_73 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_74 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_75 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_76 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_77 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_78 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_79 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_80 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_81 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_82 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_83 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_84 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_85 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_86 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_87 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");
	var mask_1_graphics_88 = new cjs.Graphics().p("EgjiAMqIAA5TMBHFAAAIAAZTg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:237.5,y:79}).wait(34).to({graphics:mask_1_graphics_34,x:237.5,y:79}).wait(1).to({graphics:mask_1_graphics_35,x:245.3,y:79}).wait(1).to({graphics:mask_1_graphics_36,x:253,y:79}).wait(1).to({graphics:mask_1_graphics_37,x:260.8,y:79}).wait(1).to({graphics:mask_1_graphics_38,x:268.6,y:79}).wait(1).to({graphics:mask_1_graphics_39,x:276.4,y:79}).wait(1).to({graphics:mask_1_graphics_40,x:284.1,y:79}).wait(1).to({graphics:mask_1_graphics_41,x:291.9,y:79}).wait(1).to({graphics:mask_1_graphics_42,x:299.7,y:79}).wait(1).to({graphics:mask_1_graphics_43,x:307.5,y:79}).wait(1).to({graphics:mask_1_graphics_44,x:315.3,y:79}).wait(1).to({graphics:mask_1_graphics_45,x:323,y:79}).wait(1).to({graphics:mask_1_graphics_46,x:330.8,y:79}).wait(1).to({graphics:mask_1_graphics_47,x:338.6,y:79}).wait(1).to({graphics:mask_1_graphics_48,x:346.4,y:79}).wait(1).to({graphics:mask_1_graphics_49,x:354.1,y:79}).wait(1).to({graphics:mask_1_graphics_50,x:361.9,y:79}).wait(1).to({graphics:mask_1_graphics_51,x:369.7,y:79}).wait(1).to({graphics:mask_1_graphics_52,x:377.5,y:79}).wait(1).to({graphics:mask_1_graphics_53,x:385.3,y:79}).wait(1).to({graphics:mask_1_graphics_54,x:393,y:79}).wait(1).to({graphics:mask_1_graphics_55,x:400.8,y:79}).wait(1).to({graphics:mask_1_graphics_56,x:408.6,y:79}).wait(1).to({graphics:mask_1_graphics_57,x:416.4,y:79}).wait(1).to({graphics:mask_1_graphics_58,x:424.1,y:79}).wait(1).to({graphics:mask_1_graphics_59,x:431.9,y:79}).wait(1).to({graphics:mask_1_graphics_60,x:439.7,y:79}).wait(1).to({graphics:mask_1_graphics_61,x:447.5,y:79}).wait(1).to({graphics:mask_1_graphics_62,x:455.3,y:79}).wait(1).to({graphics:mask_1_graphics_63,x:463,y:79}).wait(1).to({graphics:mask_1_graphics_64,x:470.8,y:79}).wait(1).to({graphics:mask_1_graphics_65,x:478.6,y:79}).wait(1).to({graphics:mask_1_graphics_66,x:486.4,y:79}).wait(1).to({graphics:mask_1_graphics_67,x:494.1,y:79}).wait(1).to({graphics:mask_1_graphics_68,x:501.9,y:79}).wait(1).to({graphics:mask_1_graphics_69,x:509.7,y:79}).wait(1).to({graphics:mask_1_graphics_70,x:517.5,y:79}).wait(1).to({graphics:mask_1_graphics_71,x:525.3,y:79}).wait(1).to({graphics:mask_1_graphics_72,x:533,y:79}).wait(1).to({graphics:mask_1_graphics_73,x:540.8,y:79}).wait(1).to({graphics:mask_1_graphics_74,x:548.6,y:79}).wait(1).to({graphics:mask_1_graphics_75,x:556.4,y:79}).wait(1).to({graphics:mask_1_graphics_76,x:564.1,y:79}).wait(1).to({graphics:mask_1_graphics_77,x:571.9,y:79}).wait(1).to({graphics:mask_1_graphics_78,x:579.7,y:79}).wait(1).to({graphics:mask_1_graphics_79,x:587.5,y:79}).wait(1).to({graphics:mask_1_graphics_80,x:595.3,y:79}).wait(1).to({graphics:mask_1_graphics_81,x:603,y:79}).wait(1).to({graphics:mask_1_graphics_82,x:610.8,y:79}).wait(1).to({graphics:mask_1_graphics_83,x:618.6,y:79}).wait(1).to({graphics:mask_1_graphics_84,x:626.4,y:79}).wait(1).to({graphics:mask_1_graphics_85,x:634.1,y:79}).wait(1).to({graphics:mask_1_graphics_86,x:641.9,y:79}).wait(1).to({graphics:mask_1_graphics_87,x:649.7,y:79}).wait(1).to({graphics:mask_1_graphics_88,x:657.5,y:79}).wait(1).to({graphics:null,x:0,y:0}).wait(261));

	// Слой 9
	this.instance_2 = new lib.Символ8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(218,82,1,1,0,0,0,218,82);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:true},1).wait(261));

	// Слой 2
	this.instance_3 = new lib.Символ4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(221,70.5,1,1,0,0,0,218,114.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(144).to({x:218},0).to({x:198.1},13,cjs.Ease.get(-1)).to({x:184},12,cjs.Ease.get(1)).wait(50).to({x:104.1,alpha:0},15,cjs.Ease.get(-1)).to({_off:true},1).wait(115));

	// Слой 4
	this.instance_4 = new lib.Символ3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(220,70.5,1,1,0,0,0,218,114.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(144).to({x:218},0).to({x:216.3},13,cjs.Ease.get(-1)).to({x:219},12,cjs.Ease.get(1)).wait(50).to({x:155,alpha:0},15,cjs.Ease.get(-1)).to({_off:true},1).wait(115));

	// Слой 5
	this.instance_5 = new lib.Символ5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(219,70.5,1,1,0,0,0,218,114.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(144).to({x:218},0).to({x:233.5},13,cjs.Ease.get(-1)).to({x:252},12,cjs.Ease.get(1)).wait(50).to({x:298,alpha:0},15,cjs.Ease.get(-1)).to({_off:true},1).wait(115));

	// Слой 7
	this.instance_6 = new lib.Символ6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(218,70.5,1,1,0,0,0,218,114.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(144).to({x:251.7},13,cjs.Ease.get(-1)).to({x:287},12,cjs.Ease.get(1)).wait(50).to({x:352,alpha:0},15,cjs.Ease.get(-1)).to({_off:true},1).wait(115));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-44,440,229);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.instance = new lib.Символ2();
	this.instance.parent = this;
	this.instance.setTransform(924,305,1,1,0,0,0,218,82);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:373},34,cjs.Ease.get(1)).to({_off:true},201).wait(115));

	// Слой 3
	this.instance_1 = new lib.Символ11();
	this.instance_1.parent = this;
	this.instance_1.setTransform(380.6,395.4,1,1,0,0,0,32.5,9.9);

	this.instance_2 = new lib.Символ15();
	this.instance_2.parent = this;
	this.instance_2.setTransform(390.3,393.2,1,1,0,0,0,66.2,10);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},34).to({state:[{t:this.instance_2}]},54).to({state:[{t:this.instance_2}]},46).to({state:[{t:this.instance_2}]},10).to({state:[]},1).wait(205));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).wait(46).to({alpha:0},10).to({_off:true},1).wait(205));

	// Слой 4
	this.instance_3 = new lib.Символ14();
	this.instance_3.parent = this;
	this.instance_3.setTransform(396.9,484.9,1,1,0,0,0,84.7,20.4);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(149).to({_off:false},0).to({y:434.9},15,cjs.Ease.get(1)).wait(60).to({y:424.9,alpha:0},10).to({_off:true},1).wait(115));

	// Слой 1
	this.instance_4 = new lib.Символ13();
	this.instance_4.parent = this;
	this.instance_4.setTransform(395.4,447.9,1,1,0,0,0,251.3,20.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(17).to({_off:false},0).to({y:437.9,alpha:1},17,cjs.Ease.get(1)).wait(100).to({y:427.9,alpha:0},15).to({_off:true},1).wait(200));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(706,179,465,229);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol24();
	this.instance.parent = this;
	this.instance.setTransform(-109,-63,1,1,0,0,0,119,119);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:127,y:-299.1},299).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-466,-182,952,714);


(lib.Символ25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Symbol23();
	this.instance.parent = this;
	this.instance.setTransform(767.9,395.2,1.312,1.312,0,0,0,119,119);
	this.instance.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhhmBJNMAAAiSaMDDNAAAMAAACSag");
	this.shape.setTransform(624.7,468.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ25, new cjs.Rectangle(0,0,1249.5,937.1), null);


(lib.Символ21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ18();
	this.instance.parent = this;
	this.instance.setTransform(168.8,69.4,1,1,0,0,0,168.8,52);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.97,scaleY:0.97,x:168.9},9,cjs.Ease.get(-1)).to({regY:52.1,scaleX:0.93,scaleY:0.93,y:69.5},10,cjs.Ease.get(1)).to({regX:168.9,scaleX:0.96,scaleY:0.96},10,cjs.Ease.get(-1)).to({regX:168.8,regY:52,scaleX:1,scaleY:1,x:168.8,y:69.4},10,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,104);


(lib.Символ16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib.Символ17();
	this.instance.parent = this;
	this.instance.setTransform(150,14.5,1,1,0,0,0,150,14.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(239).to({scaleX:1.21,scaleY:1.21,x:275.9,y:59.8},8,cjs.Ease.get(-1)).to({regY:14.6,scaleX:1.42,scaleY:1.42,x:401.8,y:105.2},8,cjs.Ease.get(1)).wait(79).to({scaleX:1.2,scaleY:1.2,x:267.5,y:56.8},8,cjs.Ease.get(-1)).to({regY:14.5,scaleX:1,scaleY:1,x:150,y:14.5},7,cjs.Ease.get(1)).wait(1));

	// Слой 3
	this.instance_1 = new lib.Символ22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(404.3,155.4,1,1,0,0,0,217,17.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(255).to({_off:false},0).wait(79).to({y:132.8,alpha:0},15).wait(1));

	// Слой 2
	this.instance_2 = new lib.Символ21();
	this.instance_2.parent = this;
	this.instance_2.setTransform(408.7,265.8,1.218,1.218,0,0,0,168.9,52.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(255).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},14,cjs.Ease.get(1)).wait(65).to({y:288.4,alpha:0},15).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,29);


(lib.Символ23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_15 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(15).call(this.frame_15).wait(17));

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AobGsQjfixAAj7QAAj5DfiyQDfixE8AAQE9AADeCxQDgCyAAD5QAAD7jgCxQjeCxk9AAQk8AAjfixg");
	this.shape.setTransform(1200.8,-378);

	this.instance = new lib.Символ17();
	this.instance.parent = this;
	this.instance.setTransform(401.8,105.2,1.417,1.417,0,0,0,150,14.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},15).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({alpha:1},14).wait(1).to({alpha:0},15,cjs.Ease.get(-1)).wait(1));

	// Слой 2
	this.instance_1 = new lib.Символ22();
	this.instance_1.parent = this;
	this.instance_1.setTransform(404.3,155.4,1,1,0,0,0,217,17.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({alpha:1},14).wait(1).to({y:132.8,alpha:0},15).wait(1));

	// Слой 3
	this.instance_2 = new lib.Символ21();
	this.instance_2.parent = this;
	this.instance_2.setTransform(408.7,265.8,1.218,1.218,0,0,0,168.9,52.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},14,cjs.Ease.get(1)).wait(1).to({y:288.4,alpha:0},15).wait(1));

	// Слой 5
	this.instance_3 = new lib.Символ25();
	this.instance_3.parent = this;
	this.instance_3.setTransform(333.5,443.2,1,1,0,0,0,624.7,468.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({alpha:1},14).to({alpha:0},16).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1124.5,-438.5,152.6,121.1);


// stage content:
(lib.getcar6003002 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stage.canvas.addEventListener("mouseover", fl_Clickover3.bind(this));
		
		function fl_Clickover3()
		{
		
			this.logo.alpha=0;
			this.car.alpha=0;
			this.over.gotoAndPlay(1);
		
		}
		
		stage.canvas.addEventListener("mouseout", fl_Clickout3.bind(this));
		
		function fl_Clickout3()
		{
		
			this.logo.alpha=1;
			this.car.alpha=1;
			this.over.gotoAndPlay(17);
		
		}
		
		document.addEventListener("click", fl_ClickToGoToWebPage);
				
				function fl_ClickToGoToWebPage() {
				window.open(clickTAG, "_blank");
				}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Symbol 5
	this.over = new lib.Символ23();
	this.over.parent = this;
	this.over.setTransform(98.6,54.9,0.76,0.76,0,0,0,133,60);

	this.timeline.addTween(cjs.Tween.get(this.over).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(2,1,1).p("EgtdgV8MBa7AAAMAAAAr5Mha7AAAg");
	this.shape.setTransform(301,150.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.logo = new lib.Символ16();
	this.logo.parent = this;
	this.logo.setTransform(129.6,35.6,0.663,0.663,0,0,0,150.2,14.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// Symbol 18
	this.car = new lib.Символ1();
	this.car.parent = this;
	this.car.setTransform(-31.9,-156.4,1,1,0,0,0,58,19.5);

	this.timeline.addTween(cjs.Tween.get(this.car).wait(1));

	// Layer 1
	this.instance = new lib.Symbol23();
	this.instance.parent = this;
	this.instance.setTransform(360,289,1,1,0,0,0,119,119);
	this.instance.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(74.9,-174,1306.1,1026);
// library properties:
lib.properties = {
	id: '56928B180F53483FA69AE67D2E6064B5',
	width: 600,
	height: 300,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/back.jpg?1507650471230", id:"back"},
		{src:"images/Bitmap5.png?1507650471230", id:"Bitmap5"},
		{src:"images/mitsubishi7.png?1507650471230", id:"mitsubishi7"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56928B180F53483FA69AE67D2E6064B5'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;